package com.example.screentranslator

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "ترجم شاشتي\n\nترجمة الشاشة من الألمانية إلى العربية. فعّل خدمة إمكانية الوصول حتى يظهر زر الترجمة العائم."
            textSize = 20f
        })
        root.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "\nبعد فتح الإعدادات، اختر «ترجم شاشتي» وفعّل الخدمة. ارجع إلى التطبيق، ثم افتح أي تطبيق واضغط زر (ع) العائم."
            textSize = 16f
        })
        setContentView(root)
    }
}
