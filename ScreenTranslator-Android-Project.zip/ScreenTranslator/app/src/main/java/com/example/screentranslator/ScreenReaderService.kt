package com.example.screentranslator

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.io.ByteArrayOutputStream

class ScreenReaderService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bubble: Button? = null
    private var resultView: TextView? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun showBubble() {
        if (bubble != null) return
        val b = Button(this).apply {
            text = "ع"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(35, 100, 190))
            setOnClickListener { captureAndTranslate() }
        }
        val p = WindowManager.LayoutParams(
            dp(54), dp(54), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL; x = dp(8) }
        bubble = b
        wm.addView(b, p)
    }

    private fun captureAndTranslate() {
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        val buffer = result.hardwareBuffer
                        val bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        buffer.close()
                        if (bitmap == null) { showResult("تعذر قراءة صورة الشاشة."); return }
                        val mutable = bitmap.copy(Bitmap.Config.ARGB_8888, false)
                        bitmap.recycle()
                        recognize(mutable)
                    }
                    override fun onFailure(errorCode: Int) {
                        showResult("تعذر التقاط الشاشة. تأكد من تفعيل صلاحية إمكانية الوصول.")
                    }
                })
        } catch (e: Exception) {
            showResult("لم أستطع التقاط الشاشة: ${e.localizedMessage ?: "خطأ غير معروف"}")
        }
    }

    private fun recognize(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { result ->
                val source = result.text.trim()
                bitmap.recycle()
                if (source.isBlank()) { showResult("لم أجد نصاً واضحاً على الشاشة."); return@addOnSuccessListener }
                translate(source)
            }
            .addOnFailureListener {
                bitmap.recycle()
                showResult("حدث خطأ أثناء قراءة النص.")
            }
    }

    private fun translate(source: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(com.google.mlkit.nl.translate.TranslateLanguage.GERMAN)
            .setTargetLanguage(com.google.mlkit.nl.translate.TranslateLanguage.ARABIC)
            .build()
        val translator = Translation.getClient(options)
        showResult("جارٍ تجهيز الترجمة الألمانية → العربية…")
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(source)
                    .addOnSuccessListener { translated ->
                        showResult(translated)
                        translator.close()
                    }
                    .addOnFailureListener {
                        showResult("فشلت الترجمة. تحقق من اتصال الإنترنت وحاول مجدداً.")
                        translator.close()
                    }
            }
            .addOnFailureListener {
                showResult("تعذر تنزيل نموذج الترجمة. اتصل بالإنترنت وحاول مجدداً.")
                translator.close()
            }
    }

    private fun showResult(text: String) {
        main.post {
            try {
                resultView?.let { wm.removeView(it) }
                val panel = TextView(this).apply {
                    this.text = text
                    textSize = 18f
                    setTextColor(Color.WHITE)
                    setBackgroundColor(0xEE20242A.toInt())
                    setPadding(dp(18), dp(18), dp(18), dp(18))
                    setOnClickListener { try { wm.removeView(this); resultView = null } catch (_: Exception) {} }
                }
                val params = WindowManager.LayoutParams(
                    (resources.displayMetrics.widthPixels * 0.88f).toInt(),
                    (resources.displayMetrics.heightPixels * 0.55f).toInt(),
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.CENTER }
                resultView = panel
                wm.addView(panel, params)
            } catch (_: Exception) {}
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { resultView?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
